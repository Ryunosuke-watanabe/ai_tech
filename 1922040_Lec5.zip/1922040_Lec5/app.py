from dataaccess import DataAccess
import numpy as np
from math import sin, cos, acos, radians

num = input("1→空間的に近い場所を検索, 2→２点間の移動時間)

da = DataAccess()

if num == "1":
    loc = input("検索したい場所を入力してください。")
    spot_list = da.get_lat_lng(loc)
    spot_list2 = da.get_lat_lng2(loc)

    base = np.array([])
    b = np.array([])
    kekka = np.array([])

    ### 大円距離のための関数

    def latlng_to_xyz(lat, lng):
        rlat, rlng = radians(lat), radians(lng)
        coslat = cos(rlat)
        return coslat*cos(rlng), coslat*sin(rlng), sin(rlat)

    def dist_on_sphere(pos0lat, pos0lng, pos1lat, pos1lng, radius=6378.137):
        xyz0, xyz1 = latlng_to_xyz(pos0lat, pos0lng), latlng_to_xyz(pos1lat, pos1lng)
        return acos(sum(x * y for x, y in zip(xyz0, xyz1)))*radius

    ### ここまで

    if len(spot_list) != 0:
        for spot in spot_list:
            base = np.append(base, list(spot))
        for spots in spot_list2:
            b = np.append(b, list(spots), axis=0)
        b = b.reshape(len(spot_list2), int(len(b) / len(spot_list2)))

        for item in b:
            # ans = np.linalg.norm(base - np.array([item[1:]], dtype=float))
            ans = dist_on_sphere(base[0], base[1], float(item[1]), float(item[2]))
            if len(kekka) == 0 or float(kekka[1]) > ans:
                kekka = np.array([])
                kekka = np.append(kekka, [item[0],ans])
        print(kekka[0], kekka[1]+'km')
    else:
        print("検索結果はありませんでした。バンナ公園、石垣島鍾乳洞、石垣やいま村を入力してみてください。")

if num == "2":
    loc = input("検索したい場所を入力してください。")
    loc2 = input("もう一つ入力してください。")
    spot_list = da.get_lat_lng(loc)
    spot_list2 = da.get_lat_lng(loc2)

    base = np.array([])
    b = np.array([])
    kekka = np.array([])

    ### 大円距離のための関数

    def latlng_to_xyz(lat, lng):
        rlat, rlng = radians(lat), radians(lng)
        coslat = cos(rlat)
        return coslat*cos(rlng), coslat*sin(rlng), sin(rlat)

    def dist_on_sphere(pos0lat, pos0lng, pos1lat, pos1lng, radius=6378.137):
        xyz0, xyz1 = latlng_to_xyz(pos0lat, pos0lng), latlng_to_xyz(pos1lat, pos1lng)
        return acos(sum(x * y for x, y in zip(xyz0, xyz1)))*radius

    ### ここまで

    if len(spot_list) != 0 or len(spot_list2) != 0:
        for spot in spot_list:
            base = np.append(base, list(spot))
        for spots in spot_list2:
            b = np.append(b, list(spots))

        print(loc, 'から', loc2, 'までの距離は', dist_on_sphere(base[0], base[1], b[0], b[1]), 'kmです。')
        print('時速4kmで移動する場合,かかる時間は', dist_on_sphere(base[0], base[1], b[0], b[1])/4, '時間です。')

    else:
        print("検索結果はありませんでした。")

if num == "3":
    loc = input("検索したい場所を入力してください。")
    spot_list = da.get_spots_sensitivity(loc)
    spot_list2 = da.get_spots_sensitivity2(loc)

    base = np.array([])
    b = np.array([])
    kekka = np.empty((0,2))

    def latlng_to_xyz(lat, lng):
        rlat, rlng = radians(lat), radians(lng)
        coslat = cos(rlat)
        return coslat*cos(rlng), coslat*sin(rlng), sin(rlat)

    def dist_on_sphere(pos0lat, pos0lng, pos1lat, pos1lng, radius=6378.137):
        xyz0, xyz1 = latlng_to_xyz(pos0lat, pos0lng), latlng_to_xyz(pos1lat, pos1lng)
        return acos(sum(x * y for x, y in zip(xyz0, xyz1)))*radius

    if len(spot_list) != 0:
        for spot in spot_list:
            base = np.append(base, list(spot))
        for spots in spot_list2:
            b = np.append(b, list(spots), axis=0)
        b = b.reshape(len(spot_list2), int(len(b) / len(spot_list2)))

        for item in b:
            ans = np.sum(base * np.array([item[1:]], dtype=float))
            kekka = np.append(kekka, np.array([[item[0], ans]]), axis=0)
        kekka_ = np.sort(kekka, axis=0)[-4:]
        print(kekka_)
        kyori = np.array([])
        for loca in kekka_[:, 0]:
            spot_list = da.get_lat_lng(loca)
            for spot in spot_list:
                kyori = np.append(kyori, list(spot))
        print(kyori)
    else:
        print("検索結果はありませんでした。")

if num != "1" and num != "2" and num != "3":
    print('0か1か2を入力してください。')