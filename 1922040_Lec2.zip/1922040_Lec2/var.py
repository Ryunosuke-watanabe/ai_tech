class Var:
    hostname = "localhost"
    port = "5432"
    dbname = "ai_tech"
    username = "ryu"
    password = "ryunosuke0904"